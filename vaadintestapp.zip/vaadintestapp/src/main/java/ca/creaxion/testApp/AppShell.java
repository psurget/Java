package ca.creaxion.testApp;

import com.vaadin.flow.component.page.AppShellConfigurator;
import com.vaadin.flow.server.PWA;

@PWA(name = "Project Base for Vaadin Flow with Spring", shortName = "Project Base")
public class AppShell implements AppShellConfigurator {
}
